<div class="wrap">
    <div id="woocommerce-gift-coupon">
        <?php _e( '<h2>Woocommerce Gift Coupon - Options</h2>', 'woocommerce-gift-coupon' ); ?>
        <div id="gs-middle">
            <?php require_once( WOOCOMMERCE_GIFT_COUPON_DIR."admin/includes/gs-middle-options-page.php" ); ?>
        </div>
    </div>
</div>



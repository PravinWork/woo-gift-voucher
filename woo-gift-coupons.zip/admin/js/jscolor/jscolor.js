jQuery(document).ready(function($){
    $('.woocommerce-gift-coupon-color').wpColorPicker();
});